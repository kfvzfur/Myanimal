//
//  ViewCell2.swift
//  myapi
//
//  Created by 馬馬桑 on 2019/5/18.
//  Copyright © 2019  kfvzfur. All rights reserved.
//

import UIKit

class ViewCell2: UICollectionViewCell {
    
    @IBOutlet weak var cell2lable: UILabel!
    @IBOutlet weak var cell2image: UIImageView!
}
